
package com.example.excessbaggagecalculator;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        // Show the application title and back button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("About");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        TextView tvWebsite = findViewById(R.id.tvWebsite);

        String appUrl = "YOUR_GITHUB_URL";

        tvWebsite.setText(appUrl);
        tvWebsite.setAutoLinkMask(0);
        tvWebsite.setPaintFlags(
                tvWebsite.getPaintFlags()
                        | android.graphics.Paint.UNDERLINE_TEXT_FLAG);

        tvWebsite.setOnClickListener(v -> {
            android.content.Intent intent =
                    new android.content.Intent(
                            android.content.Intent.ACTION_VIEW,
                            android.net.Uri.parse(appUrl));

            startActivity(intent);
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
