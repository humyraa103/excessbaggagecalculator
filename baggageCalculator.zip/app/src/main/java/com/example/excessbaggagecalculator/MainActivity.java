package com.example.excessbaggagecalculator;

import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText etWeight, etRate;
    private Spinner spinnerClass;

    private TextView tvAllowance;
    private TextView tvResultMessage;
    private TextView tvExcessWeight;
    private TextView tvExcessCharge;
    private TextView tvTax;
    private TextView tvTotal;

    private final DecimalFormat moneyFormat =
            new DecimalFormat("#,##0.00");

    private final DecimalFormat weightFormat =
            new DecimalFormat("0.##");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        androidx.appcompat.widget.Toolbar toolbar =
                findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main), (v, insets) -> {

                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars());

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                });

        // Connect XML components
        etWeight = findViewById(R.id.etWeight);
        etRate = findViewById(R.id.etRate);
        spinnerClass = findViewById(R.id.spinnerClass);

        tvAllowance = findViewById(R.id.tvAllowance);
        tvResultMessage = findViewById(R.id.tvResultMessage);
        tvExcessWeight = findViewById(R.id.tvExcessWeight);
        tvExcessCharge = findViewById(R.id.tvExcessCharge);
        tvTax = findViewById(R.id.tvTax);
        tvTotal = findViewById(R.id.tvTotal);

        Button btnCalculate = findViewById(R.id.btnCalculate);
        Button btnReset = findViewById(R.id.btnReset);

        // Set up ticket class options
        String[] ticketClasses = {"Economy", "Business"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                ticketClasses
        );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        spinnerClass.setAdapter(adapter);

        // Update the baggage allowance when the class changes
        spinnerClass.setOnItemSelectedListener(
                new android.widget.AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            android.widget.AdapterView<?> parent,
                            View view,
                            int position,
                            long id) {

                        updateAllowance();
                    }

                    @Override
                    public void onNothingSelected(
                            android.widget.AdapterView<?> parent) {
                    }
                });

        // Calculate button
        btnCalculate.setOnClickListener(v -> calculateFee());

        // Reset button
        btnReset.setOnClickListener(v -> resetCalculator());



        updateAllowance();
    }

    private double getAllowance() {
        if (spinnerClass.getSelectedItemPosition() == 1) {
            return 40.0; // Business class
        }

        return 20.0; // Economy class
    }

    private void updateAllowance() {
        double allowance = getAllowance();

        tvAllowance.setText(
                "Included baggage allowance: "
                        + weightFormat.format(allowance) + " kg");
    }

    private void calculateFee() {

        String weightText = etWeight.getText().toString().trim();
        String rateText = etRate.getText().toString().trim();

        // Validate empty inputs
        if (weightText.isEmpty()) {
            etWeight.setError("Please enter baggage weight.");
            etWeight.requestFocus();
            return;
        }

        if (rateText.isEmpty()) {
            etRate.setError("Please enter the rate per kg.");
            etRate.requestFocus();
            return;
        }

        double baggageWeight;
        double rate;

        try {
            baggageWeight = Double.parseDouble(weightText);
            rate = Double.parseDouble(rateText);
        } catch (NumberFormatException e) {
            Toast.makeText(
                    this,
                    "Please enter valid numbers.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Validate negative values
        if (!Double.isFinite(baggageWeight)
                || baggageWeight < 0) {

            etWeight.setError(
                    "Weight must be zero or greater.");
            etWeight.requestFocus();
            return;
        }

        if (!Double.isFinite(rate) || rate < 0) {

            etRate.setError(
                    "Rate must be zero or greater.");
            etRate.requestFocus();
            return;
        }

        // Calculate excess baggage weight
        double allowance = getAllowance();

        double excessWeight = Math.max(
                0.0, baggageWeight - allowance);

        // Calculate charge and 8% service tax
        double excessCharge = excessWeight * rate;
        double serviceTax = excessCharge * 0.08;
        double totalPayable = excessCharge + serviceTax;

        // Display the results
        tvExcessWeight.setText(
                weightFormat.format(excessWeight) + " kg");

        tvExcessCharge.setText(
                "RM " + moneyFormat.format(excessCharge));

        tvTax.setText(
                "RM " + moneyFormat.format(serviceTax));

        tvTotal.setText(
                "RM " + moneyFormat.format(totalPayable));

        if (excessWeight == 0.0) {
            tvResultMessage.setText(
                    "Your baggage is within the allowed limit. "
                            + "No excess baggage fee is required.");
        } else {
            tvResultMessage.setText(
                    "Your baggage exceeds the allowance by "
                            + weightFormat.format(excessWeight)
                            + " kg.");
        }
    }

    private void resetCalculator() {

        etWeight.setText("");
        etRate.setText("");

        etWeight.setError(null);
        etRate.setError(null);

        spinnerClass.setSelection(0);

        tvExcessWeight.setText("— kg");
        tvExcessCharge.setText("RM 0.00");
        tvTax.setText("RM 0.00");
        tvTotal.setText("RM 0.00");

        tvResultMessage.setText(
                "Enter your baggage details and calculate your fee.");

        updateAllowance();

        etWeight.requestFocus();
    }

    @Override
    public boolean onCreateOptionsMenu(android.view.Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(
            android.view.MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_share) {

            String appUrl = "YOUR_GITHUB_URL";

            android.content.Intent shareIntent =
                    new android.content.Intent(
                            android.content.Intent.ACTION_SEND);

            shareIntent.setType("text/plain");
            shareIntent.putExtra(
                    android.content.Intent.EXTRA_SUBJECT,
                    "Excess Baggage Calculator");

            shareIntent.putExtra(
                    android.content.Intent.EXTRA_TEXT,
                    "Try my Excess Baggage Calculator app!\n"
                            + appUrl);

            startActivity(
                    android.content.Intent.createChooser(
                            shareIntent, "Share application"));

            return true;

        } else if (id == R.id.action_about) {

            startActivity(new android.content.Intent(
                    MainActivity.this, AboutActivity.class));

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
